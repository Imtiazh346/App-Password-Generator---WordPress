<?php
/**
 * Plugin Name:       App Password Generator
 * Description:       Create, test and revoke WordPress Application Passwords from a simple admin screen. Works even when the profile page fails to show the new key. Adds Tools → App Password Generator.
 * Version:           1.1.0
 * Requires at least: 5.6
 * Requires PHP:      7.0
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       app-password-generator
 * Update URI:        false
 *
 * @package AppPasswordGenerator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'APG_VERSION', '1.1.0' );

/**
 * Main plugin class. Everything is static: the plugin has no settings and stores nothing.
 */
final class APG_App_Password_Generator {

	const SLUG = 'app-password-generator';

	/**
	 * Hooks the plugin into WordPress. Only runs in the admin area.
	 */
	public static function init() {
		if ( ! is_admin() ) {
			return;
		}
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * Capability needed to open the tool. Change it with the `apg_required_capability` filter.
	 *
	 * @return string
	 */
	private static function required_cap() {
		return (string) apply_filters( 'apg_required_capability', 'manage_options' );
	}

	public static function add_menu() {
		add_management_page(
			__( 'App Password Generator', 'app-password-generator' ),
			__( 'App Password Generator', 'app-password-generator' ),
			self::required_cap(),
			self::SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	public static function action_links( $links ) {
		$link = '<a href="' . esc_url( self::page_url() ) . '">' . esc_html__( 'Open', 'app-password-generator' ) . '</a>';
		array_unshift( $links, $link );
		return $links;
	}

	private static function page_url( $user_id = 0 ) {
		$args = array( 'page' => self::SLUG );
		if ( $user_id ) {
			$args['user_id'] = (int) $user_id;
		}
		return add_query_arg( $args, admin_url( 'tools.php' ) );
	}

	/**
	 * Works out which user is being managed. Defaults to the logged-in user.
	 *
	 * @param WP_User $current Logged-in user.
	 * @return array{0: WP_User, 1: string} The target user and an optional error message.
	 */
	private static function get_target_user( WP_User $current ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only selection; every write action is nonce-checked.
		$requested = isset( $_REQUEST['user_id'] ) ? absint( $_REQUEST['user_id'] ) : 0;

		if ( ! $requested || $requested === $current->ID ) {
			return array( $current, '' );
		}

		$user = get_userdata( $requested );
		if ( ! $user || ! current_user_can( 'edit_user', $user->ID ) ) {
			return array( $current, __( 'You cannot manage application passwords for that user, so your own account is shown instead.', 'app-password-generator' ) );
		}

		return array( $user, '' );
	}

	/**
	 * Processes create / revoke / revoke-all form submissions.
	 *
	 * @param WP_User $user Target user.
	 * @return array{new: array|null, notices: array}
	 */
	private static function handle_request( WP_User $user ) {
		$out = array(
			'new'     => null,
			'notices' => array(),
		);

		if ( ! isset( $_SERVER['REQUEST_METHOD'] ) || 'POST' !== $_SERVER['REQUEST_METHOD'] || empty( $_POST['apg_action'] ) ) {
			return $out;
		}

		$action = sanitize_key( wp_unslash( $_POST['apg_action'] ) );

		switch ( $action ) {

			case 'create':
				check_admin_referer( 'apg_create_' . $user->ID );

				if ( ! current_user_can( 'create_app_password', $user->ID ) ) {
					$out['notices'][] = array( 'error', __( 'You are not allowed to create application passwords for this user.', 'app-password-generator' ) );
					break;
				}

				$name = isset( $_POST['apg_name'] ) ? sanitize_text_field( wp_unslash( $_POST['apg_name'] ) ) : '';
				if ( '' === $name ) {
					/* translators: %s: current date and time. */
					$name = sprintf( __( 'App Password %s', 'app-password-generator' ), wp_date( 'Y-m-d H:i:s' ) );
				}

				if ( self::name_exists( $user->ID, $name ) ) {
					/* translators: %s: application password name. */
					$out['notices'][] = array( 'error', sprintf( __( 'An application password named "%s" already exists for this user. Choose a different name so you can tell them apart.', 'app-password-generator' ), $name ) );
					break;
				}

				$created = WP_Application_Passwords::create_new_application_password( $user->ID, array( 'name' => $name ) );

				if ( is_wp_error( $created ) ) {
					$out['notices'][] = array( 'error', $created->get_error_message() );
					break;
				}

				$plain      = $created[0];
				$out['new'] = array(
					'name'     => $name,
					'password' => WP_Application_Passwords::chunk_password( $plain ),
					'test'     => ! empty( $_POST['apg_test'] ) ? self::test_password( $user, $plain ) : null,
				);
				break;

			case 'revoke':
				$uuid = isset( $_POST['apg_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['apg_uuid'] ) ) : '';
				check_admin_referer( 'apg_revoke_' . $user->ID . '_' . $uuid );

				if ( ! current_user_can( 'delete_app_password', $user->ID, $uuid ) ) {
					$out['notices'][] = array( 'error', __( 'You are not allowed to revoke this application password.', 'app-password-generator' ) );
					break;
				}

				$deleted = WP_Application_Passwords::delete_application_password( $user->ID, $uuid );
				$out['notices'][] = is_wp_error( $deleted )
					? array( 'error', $deleted->get_error_message() )
					: array( 'success', __( 'Application password revoked.', 'app-password-generator' ) );
				break;

			case 'revoke_all':
				check_admin_referer( 'apg_revoke_all_' . $user->ID );

				if ( ! current_user_can( 'delete_app_passwords', $user->ID ) ) {
					$out['notices'][] = array( 'error', __( 'You are not allowed to revoke application passwords for this user.', 'app-password-generator' ) );
					break;
				}

				$count = WP_Application_Passwords::delete_all_application_passwords( $user->ID );
				if ( is_wp_error( $count ) ) {
					$out['notices'][] = array( 'error', $count->get_error_message() );
				} else {
					/* translators: %d: number of revoked passwords. */
					$out['notices'][] = array( 'success', sprintf( _n( '%d application password revoked.', '%d application passwords revoked.', $count, 'app-password-generator' ), $count ) );
				}
				break;
		}

		return $out;
	}

	/**
	 * Whether the user already has an application password with this name.
	 * Uses the core helper when present (WP 5.7+), with a manual fallback for 5.6.
	 *
	 * @param int    $user_id User ID.
	 * @param string $name    Name to check.
	 * @return bool
	 */
	private static function name_exists( $user_id, $name ) {
		if ( method_exists( 'WP_Application_Passwords', 'application_name_exists_for_user' ) ) {
			return WP_Application_Passwords::application_name_exists_for_user( $user_id, $name );
		}
		foreach ( WP_Application_Passwords::get_user_application_passwords( $user_id ) as $item ) {
			if ( isset( $item['name'] ) && strtolower( $item['name'] ) === strtolower( $name ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Logs in to this site's own REST API with the new password, the same way an external app would.
	 *
	 * @param WP_User $user     User the password belongs to.
	 * @param string  $password Plain password (no spaces).
	 * @return array{0: string, 1: string} Status (success|warning|error) and an HTML message.
	 */
	private static function test_password( WP_User $user, $password ) {
		$response = wp_remote_get(
			rest_url( 'wp/v2/users/me' ),
			array(
				'timeout'   => 15,
				'headers'   => array(
					// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Required for HTTP Basic auth.
					'Authorization' => 'Basic ' . base64_encode( $user->user_login . ':' . $password ),
				),
				'sslverify' => apply_filters( 'https_local_ssl_verify', false ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'warning',
				sprintf(
					/* translators: %s: error message. */
					__( 'The test could not run because this site could not connect to itself (%s). This does <strong>not</strong> mean the password is broken; many hosts block these self-requests. Test it from your app or with the cURL command above.', 'app-password-generator' ),
					esc_html( $response->get_error_message() )
				),
			);
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		$err  = ( is_array( $body ) && isset( $body['code'] ) ) ? (string) $body['code'] : '';

		if ( 200 === $code && is_array( $body ) && isset( $body['id'] ) && (int) $body['id'] === $user->ID ) {
			return array( 'success', __( '<strong>Test passed.</strong> The password logged in to the REST API successfully. It is ready to use.', 'app-password-generator' ) );
		}

		switch ( $err ) {
			case 'rest_not_logged_in':
				return array( 'error', __( '<strong>Test failed: the login details never reached WordPress.</strong> Your web server or a proxy is removing the <code>Authorization</code> header. See "Authorization header is being stripped" in the README for the .htaccess / Nginx fix.', 'app-password-generator' ) );

			case 'incorrect_password':
			case 'invalid_username':
			case 'invalid_email':
				return array( 'error', __( '<strong>Test failed: WordPress rejected the login.</strong> A security or login plugin may be interfering with application password authentication. Try temporarily disabling security plugins.', 'app-password-generator' ) );

			case 'application_passwords_disabled':
			case 'application_passwords_disabled_for_user':
				return array( 'error', __( '<strong>Test failed: application passwords are disabled</strong> on this site or for this user. See the Environment check below.', 'app-password-generator' ) );
		}

		if ( 404 === $code ) {
			return array( 'error', __( '<strong>Test failed: the REST API was not found (404).</strong> Go to Settings → Permalinks and click Save to refresh rewrite rules, then try again.', 'app-password-generator' ) );
		}

		if ( in_array( $code, array( 401, 403 ), true ) && '' === $err ) {
			return array( 'error', __( '<strong>Test failed before reaching WordPress.</strong> Something in front of WordPress blocked the request, such as staging-site password protection, a firewall or a CDN rule.', 'app-password-generator' ) );
		}

		return array(
			'error',
			sprintf(
				/* translators: 1: HTTP status code, 2: error code. */
				__( '<strong>Test failed</strong> (HTTP %1$d, code: <code>%2$s</code>). The REST API may be blocked by a security plugin such as Wordfence, Solid Security or a "Disable REST API" plugin.', 'app-password-generator' ),
				$code,
				esc_html( '' !== $err ? $err : 'none' )
			),
		);
	}

	private static function notice( $type, $html ) {
		$allowed = array(
			'strong' => array(),
			'code'   => array(),
			'em'     => array(),
			'a'      => array( 'href' => array() ),
		);
		printf( '<div class="notice notice-%1$s"><p>%2$s</p></div>', esc_attr( $type ), wp_kses( $html, $allowed ) );
	}

	private static function status_row( $label, $state, $detail ) {
		$icons = array(
			'ok'    => array( '#008a20', '&#10003;' ),
			'error' => array( '#d63638', '&#10007;' ),
			'info'  => array( '#2271b1', '&#9432;' ),
		);
		list( $color, $icon ) = $icons[ $state ];
		printf(
			'<tr><th scope="row">%1$s</th><td><span style="color:%2$s;font-weight:600;">%3$s</span> %4$s</td></tr>',
			esc_html( $label ),
			esc_attr( $color ),
			$icon, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML entity.
			esc_html( $detail )
		);
	}

	public static function render_page() {
		if ( ! current_user_can( self::required_cap() ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'app-password-generator' ) );
		}

		$current = wp_get_current_user();
		list( $user, $user_error ) = self::get_target_user( $current );
		$result = self::handle_request( $user );

		$is_self            = ( $user->ID === $current->ID );
		$available          = wp_is_application_passwords_available();
		$available_for_user = wp_is_application_passwords_available_for_user( $user );
		$env                = function_exists( 'wp_get_environment_type' ) ? wp_get_environment_type() : 'production';
		$items              = WP_Application_Passwords::get_user_application_passwords( $user->ID );
		$is_post            = isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === $_SERVER['REQUEST_METHOD'];
		?>
		<style>
			.apg-card { background:#fff; border:1px solid #c3c4c7; border-left:4px solid #00a32a; padding:16px 20px; margin:16px 0; max-width:900px; }
			.apg-card h2 { margin-top:0; }
			.apg-field { display:flex; gap:8px; align-items:center; flex-wrap:wrap; }
			.apg-field input { width:100%; max-width:420px; font-family:Consolas,Monaco,monospace; }
			#apg-password { font-size:16px; letter-spacing:1px; }
			.apg-copied { color:#008a20; display:none; }
			.apg-card pre { background:#f6f7f7; padding:10px; overflow-x:auto; white-space:pre; }
			.apg-section { max-width:900px; }
			.apg-users { margin:8px 0 16px; }
		</style>

		<div class="wrap">
			<h1><?php esc_html_e( 'App Password Generator', 'app-password-generator' ); ?></h1>

			<?php
			if ( $user_error ) {
				self::notice( 'warning', esc_html( $user_error ) );
			}
			foreach ( $result['notices'] as $n ) {
				self::notice( $n[0], 'error' === $n[0] ? '<strong>' . esc_html__( 'Error:', 'app-password-generator' ) . '</strong> ' . esc_html( $n[1] ) : esc_html( $n[1] ) );
			}
			?>

			<?php if ( current_user_can( 'list_users' ) ) : ?>
				<form method="get" class="apg-users">
					<input type="hidden" name="page" value="<?php echo esc_attr( self::SLUG ); ?>">
					<label for="user_id"><strong><?php esc_html_e( 'Managing passwords for:', 'app-password-generator' ); ?></strong></label>
					<?php
					wp_dropdown_users(
						array(
							'name'     => 'user_id',
							'id'       => 'user_id',
							'selected' => $user->ID,
							'show'     => 'display_name_with_login',
						)
					);
					?>
					<button type="submit" class="button"><?php esc_html_e( 'Switch user', 'app-password-generator' ); ?></button>
				</form>
			<?php endif; ?>

			<?php
			if ( $result['new'] ) :
				$new  = $result['new'];
				$curl = sprintf( 'curl --user "%s:%s" %s', $user->user_login, $new['password'], rest_url( 'wp/v2/users/me' ) );
				?>
				<div class="apg-card">
					<h2><?php esc_html_e( 'New application password created', 'app-password-generator' ); ?></h2>
					<p><strong><?php esc_html_e( 'Copy it now. WordPress will never show this password again.', 'app-password-generator' ); ?></strong></p>

					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><?php esc_html_e( 'Name', 'app-password-generator' ); ?></th>
							<td><?php echo esc_html( $new['name'] ); ?></td>
						</tr>
						<tr>
							<th scope="row"><label for="apg-username"><?php esc_html_e( 'Username', 'app-password-generator' ); ?></label></th>
							<td class="apg-field">
								<input type="text" id="apg-username" readonly value="<?php echo esc_attr( $user->user_login ); ?>">
								<button type="button" class="button apg-copy" data-target="apg-username"><?php esc_html_e( 'Copy', 'app-password-generator' ); ?></button>
								<span class="apg-copied"><?php esc_html_e( 'Copied!', 'app-password-generator' ); ?></span>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="apg-password"><?php esc_html_e( 'Application password', 'app-password-generator' ); ?></label></th>
							<td class="apg-field">
								<input type="text" id="apg-password" readonly autocomplete="off" spellcheck="false" value="<?php echo esc_attr( $new['password'] ); ?>">
								<button type="button" class="button button-primary apg-copy" data-target="apg-password"><?php esc_html_e( 'Copy', 'app-password-generator' ); ?></button>
								<span class="apg-copied"><?php esc_html_e( 'Copied!', 'app-password-generator' ); ?></span>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="apg-site"><?php esc_html_e( 'Site URL', 'app-password-generator' ); ?></label></th>
							<td class="apg-field">
								<input type="text" id="apg-site" readonly value="<?php echo esc_attr( home_url() ); ?>">
								<button type="button" class="button apg-copy" data-target="apg-site"><?php esc_html_e( 'Copy', 'app-password-generator' ); ?></button>
								<span class="apg-copied"><?php esc_html_e( 'Copied!', 'app-password-generator' ); ?></span>
							</td>
						</tr>
					</table>

					<?php
					if ( $new['test'] ) {
						self::notice( $new['test'][0], $new['test'][1] );
					}
					?>

					<details>
						<summary><?php esc_html_e( 'Test it yourself from a terminal (cURL)', 'app-password-generator' ); ?></summary>
						<pre id="apg-curl"><?php echo esc_html( $curl ); ?></pre>
						<button type="button" class="button apg-copy" data-target="apg-curl"><?php esc_html_e( 'Copy command', 'app-password-generator' ); ?></button>
						<span class="apg-copied"><?php esc_html_e( 'Copied!', 'app-password-generator' ); ?></span>
						<p class="description"><?php esc_html_e( 'A working password returns your user details as JSON. An error mentioning "rest_not_logged_in" means the Authorization header is being stripped.', 'app-password-generator' ); ?></p>
					</details>
				</div>
			<?php endif; ?>

			<div class="apg-section">
				<h2><?php esc_html_e( 'Create a new application password', 'app-password-generator' ); ?></h2>
				<form method="post" action="<?php echo esc_url( self::page_url( $user->ID ) ); ?>">
					<?php wp_nonce_field( 'apg_create_' . $user->ID ); ?>
					<input type="hidden" name="apg_action" value="create">
					<input type="hidden" name="user_id" value="<?php echo esc_attr( $user->ID ); ?>">
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><label for="apg_name"><?php esc_html_e( 'Name', 'app-password-generator' ); ?></label></th>
							<td>
								<input type="text" name="apg_name" id="apg_name" class="regular-text" maxlength="200" placeholder="<?php esc_attr_e( 'e.g. Claude Bridge, Mobile App, Zapier', 'app-password-generator' ); ?>">
								<p class="description">
									<?php
									printf(
										/* translators: %s: username. */
										esc_html__( 'The password will belong to %s and have the same permissions as that account.', 'app-password-generator' ),
										'<strong>' . esc_html( $user->user_login ) . '</strong>'
									);
									?>
								</p>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Connection test', 'app-password-generator' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="apg_test" value="1" checked>
									<?php esc_html_e( 'Check that the new password can log in to the REST API right after creating it', 'app-password-generator' ); ?>
								</label>
							</td>
						</tr>
					</table>
					<?php submit_button( __( 'Generate Application Password', 'app-password-generator' ) ); ?>
				</form>

				<h2>
					<?php
					echo esc_html(
						$is_self
							? __( 'Your existing application passwords', 'app-password-generator' )
							/* translators: %s: username. */
							: sprintf( __( 'Existing application passwords for %s', 'app-password-generator' ), $user->user_login )
					);
					?>
				</h2>

				<?php if ( empty( $items ) ) : ?>
					<p><?php esc_html_e( 'None yet.', 'app-password-generator' ); ?></p>
				<?php else : ?>
					<table class="widefat striped">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Name', 'app-password-generator' ); ?></th>
								<th><?php esc_html_e( 'Created', 'app-password-generator' ); ?></th>
								<th><?php esc_html_e( 'Last used', 'app-password-generator' ); ?></th>
								<th><?php esc_html_e( 'Last IP', 'app-password-generator' ); ?></th>
								<th></th>
							</tr>
						</thead>
						<tbody>
						<?php foreach ( $items as $item ) : ?>
							<tr>
								<td><?php echo esc_html( $item['name'] ); ?></td>
								<td><?php echo esc_html( ! empty( $item['created'] ) ? wp_date( 'Y-m-d H:i', $item['created'] ) : '—' ); ?></td>
								<td><?php echo esc_html( ! empty( $item['last_used'] ) ? wp_date( 'Y-m-d H:i', $item['last_used'] ) : __( 'Never', 'app-password-generator' ) ); ?></td>
								<td><?php echo esc_html( ! empty( $item['last_ip'] ) ? $item['last_ip'] : '—' ); ?></td>
								<td>
									<form method="post" action="<?php echo esc_url( self::page_url( $user->ID ) ); ?>" style="margin:0;" onsubmit="return confirm('<?php echo esc_js( __( 'Revoke this application password? Any app using it will stop working.', 'app-password-generator' ) ); ?>');">
										<?php wp_nonce_field( 'apg_revoke_' . $user->ID . '_' . $item['uuid'] ); ?>
										<input type="hidden" name="apg_action" value="revoke">
										<input type="hidden" name="apg_uuid" value="<?php echo esc_attr( $item['uuid'] ); ?>">
										<input type="hidden" name="user_id" value="<?php echo esc_attr( $user->ID ); ?>">
										<button type="submit" class="button button-link-delete"><?php esc_html_e( 'Revoke', 'app-password-generator' ); ?></button>
									</form>
								</td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>

					<form method="post" action="<?php echo esc_url( self::page_url( $user->ID ) ); ?>" style="margin-top:10px;" onsubmit="return confirm('<?php echo esc_js( __( 'Revoke ALL application passwords for this user? Every app using them will stop working.', 'app-password-generator' ) ); ?>');">
						<?php wp_nonce_field( 'apg_revoke_all_' . $user->ID ); ?>
						<input type="hidden" name="apg_action" value="revoke_all">
						<input type="hidden" name="user_id" value="<?php echo esc_attr( $user->ID ); ?>">
						<button type="submit" class="button"><?php esc_html_e( 'Revoke all', 'app-password-generator' ); ?></button>
					</form>
				<?php endif; ?>

				<h2><?php esc_html_e( 'Environment check', 'app-password-generator' ); ?></h2>
				<table class="form-table" role="presentation">
					<?php
					self::status_row(
						__( 'Application Passwords on this site', 'app-password-generator' ),
						$available ? 'ok' : 'error',
						$available
							? __( 'Enabled.', 'app-password-generator' )
							: __( 'Disabled. Usual causes: the site is not on HTTPS, or a plugin/theme turned them off.', 'app-password-generator' )
					);
					self::status_row(
						__( 'For this user', 'app-password-generator' ),
						$available_for_user ? 'ok' : 'error',
						$available_for_user
							? __( 'Enabled.', 'app-password-generator' )
							: __( 'Disabled for this account by a plugin or setting.', 'app-password-generator' )
					);
					self::status_row(
						__( 'HTTPS', 'app-password-generator' ),
						is_ssl() ? 'ok' : 'info',
						is_ssl()
							? __( 'This page is loaded over HTTPS.', 'app-password-generator' )
							: __( 'This page is not loaded over HTTPS. Application Passwords need HTTPS unless the environment type is "local". If your site does use HTTPS behind a proxy/CDN, this can be ignored.', 'app-password-generator' )
					);
					self::status_row(
						__( 'Environment type', 'app-password-generator' ),
						'info',
						$env
					);
					self::status_row(
						__( 'Plugin version', 'app-password-generator' ),
						'info',
						APG_VERSION . ' / WordPress ' . get_bloginfo( 'version' )
					);
					?>
				</table>
			</div>
		</div>

		<script>
		( function () {
			<?php if ( $is_post ) : ?>
			// Turn the POST into a normal history entry so a refresh cannot create or revoke again.
			if ( window.history && window.history.replaceState ) {
				window.history.replaceState( null, '', window.location.href );
			}
			<?php endif; ?>

			function fallbackCopy( text ) {
				var ta = document.createElement( 'textarea' );
				ta.value = text;
				ta.setAttribute( 'readonly', '' );
				ta.style.position = 'absolute';
				ta.style.left = '-9999px';
				document.body.appendChild( ta );
				ta.select();
				try { document.execCommand( 'copy' ); } catch ( e ) {}
				document.body.removeChild( ta );
			}

			document.querySelectorAll( '.apg-copy' ).forEach( function ( btn ) {
				btn.addEventListener( 'click', function () {
					var el = document.getElementById( btn.getAttribute( 'data-target' ) );
					if ( ! el ) { return; }
					var text = ( 'value' in el && el.value !== undefined ) ? el.value : el.textContent;
					var done = btn.nextElementSibling;
					var show = function () {
						if ( done && done.classList.contains( 'apg-copied' ) ) {
							done.style.display = 'inline';
							setTimeout( function () { done.style.display = 'none'; }, 2000 );
						}
					};
					if ( navigator.clipboard && window.isSecureContext ) {
						navigator.clipboard.writeText( text ).then( show, function () { fallbackCopy( text ); show(); } );
					} else {
						fallbackCopy( text );
						show();
					}
				} );
			} );
		} )();
		</script>
		<?php
	}
}

APG_App_Password_Generator::init();
