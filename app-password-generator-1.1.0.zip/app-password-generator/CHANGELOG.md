# Changelog

All notable changes to this plugin are listed here.

## 1.1.0

### Added
- Automatic **connection test** after creating a password. It logs in to the site's own REST API and explains the cause of any failure (stripped Authorization header, disabled passwords, blocked REST API, staging protection, 404).
- **Manage other users:** administrators can create, list and revoke passwords for any user they can edit.
- **Revoke all** button.
- Copy buttons for username, password and site URL.
- Ready-made **cURL test command** for each new password.
- Duplicate-name check, so passwords stay easy to tell apart.
- `apg_required_capability` filter to change who can use the tool.
- Translation-ready strings (`app-password-generator` text domain).
- `Update URI: false` header, so a WordPress.org plugin with the same name can never overwrite it.

### Changed
- Environment check shows the environment type, plugin version and WordPress version.
- The HTTPS row is now informational, because proxies/CDNs can cause false warnings.
- The plugin only loads in the admin area.

## 1.0.1

### Fixed
- Refreshing the page after creating a password no longer creates a second one.
- Password field no longer autofills or spell-checks.

## 1.0.0

- First release: create an application password and show it once, list and revoke existing ones, basic environment check.
